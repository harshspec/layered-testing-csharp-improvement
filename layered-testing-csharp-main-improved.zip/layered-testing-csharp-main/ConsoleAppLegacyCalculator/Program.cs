﻿using System;
using System.Collections.Generic;
using Gas;
using NUnit.Framework;

namespace ConsoleAppLegacyCalculator
{
   class Program
   {
      static void Main(string[] args)
      {
         Console.WriteLine(" Started!");
         //Empty();
         WithOneDate();
         //WithManyDates();
         Console.WriteLine(" Completed!");
      }


      //[Test]
      public static void Empty()
      {
         // arrange
         var calculator = new LegacyCalculator();

         // act
         var result = calculator.Calculate(new List<DateTime>());

         //assert
         Assert.AreEqual(DateTime.MinValue, result.StartTime);
         Assert.AreEqual(0, result.Count);
      }

      //[Test]
      public static void WithOneDate()
      {
         // arrange
         var calculator = new LegacyCalculator();
         var dates = new List<DateTime> { new DateTime() };

         // act
         var result = calculator.Calculate(dates);

         // assert
         Assert.AreEqual(DateTime.MinValue, result.StartTime);
         Assert.AreEqual(0, result.Count);
      }

      //[Test]
      public static void WithManyDates()
      {
         // arrange
         var calculator = new LegacyCalculator();
         var dates = new List<DateTime> {
            new DateTime(2018, 1, 1),
            new DateTime(2018, 1, 2),
            new DateTime(2018, 1, 10),
            new DateTime(2018, 1, 11),
            new DateTime(2018, 1, 12),
            new DateTime(2018, 2, 20),
            new DateTime(2018, 2, 21),
            new DateTime(2018, 2, 22),
            new DateTime(2018, 2, 23)
         };

         // act
         var result = calculator.Calculate(dates);

         // assert
         //Assert.AreEqual(new DateTime(2018, 1, 8), result.StartTime);
         //Assert.AreEqual(3, result.Count);

         Assert.AreEqual(new DateTime(2018, 2, 19), result.StartTime);
         Assert.AreEqual(4, result.Count);
      }


   }
}
