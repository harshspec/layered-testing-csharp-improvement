﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Gas
{
   public partial class LegacyCalculator
   {
      //public IPlannedStart Calculate(List<DateTime> dates, int requiredDays = 1)
      //{
      //   dates.Sort((a, b) => a.CompareTo(b));

      //   var plannedStart = new PlannedStart { StartTime = DateTime.MinValue, Count = 0 };

      //   // check if dates no items then return early
      //   if (dates.Count == 0)
      //   {
      //      return plannedStart;
      //   }

      //   var requiredNumberInFirstWeek = requiredDays;

      //   var startOfFirstWeek = dates[0];
      //   // add a week
      //   var startOfSecondWeek = startOfFirstWeek.AddMilliseconds(7 * 24 * 60 * 60 * 1000);

      //   var countsForFirstWeek = dates
      //      .Where(x => x > startOfFirstWeek && x < startOfFirstWeek.AddMilliseconds(7 * 24 * 60 * 60 * 1000)) // add a week
      //      .Count()
      //      ;

      //   var countsForSecondWeek = dates
      //      .Where(x => x > startOfSecondWeek && x < startOfSecondWeek.AddMilliseconds(7 * 24 * 60 * 60 * 1000)) // add a week
      //      .Count()
      //      ;

      //   if (countsForSecondWeek > countsForFirstWeek && countsForSecondWeek >= requiredNumberInFirstWeek)
      //   {
      //      plannedStart = new PlannedStart { StartTime = startOfSecondWeek, Count = countsForSecondWeek };
      //   }
      //   return plannedStart;
      //}

      public IPlannedStart Calculate(List<DateTime> dates, int requiredDays = 1)
      {
         dates.Sort((a, b) => a.CompareTo(b));

         var plannedStart = new PlannedStart { StartTime = DateTime.MinValue, Count = 0 };

         // check if dates no items then return early
         if (dates.Count == 0)
         {
            return plannedStart;
         }
         else if(dates.Count == 1)
         {
            if(dates[0] == DateTime.MinValue) return plannedStart;
         }

         var requiredNumberInFirstWeek = requiredDays;

         var weekList = new List<int>();

         for(int i = 0; i < dates.Count; i++)
         {
            weekList.Add(GetWeekNumber(dates[i]));
         }

         var memberKeys = weekList.GroupBy(x => x)
                           .Where(x => x.Count() >= requiredNumberInFirstWeek).OrderByDescending(grp => grp.Count())
                           .Select(grp => grp)
                           .ToList();

         int week = memberKeys[0].ElementAt(0);

         for (int i = 0; i < dates.Count; i++)
         { 
            if(GetWeekNumber(dates[i]) == week)
            {
               plannedStart = new PlannedStart { StartTime = GetFirstDayOfWeek(dates[i]), Count = memberKeys[0].Count() };
               break;
            }
         }

         return plannedStart;
      }

      public static int GetWeekNumber(DateTime dtPassed)
      {
         CultureInfo ciCurr = CultureInfo.CurrentCulture;
         int weekNum = ciCurr.Calendar.GetWeekOfYear(dtPassed, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
         return weekNum;
      }

      public static DateTime GetFirstDayOfWeek(DateTime dayInWeek)
      {
         CultureInfo defaultCultureInfo = CultureInfo.CurrentCulture;
         return GetFirstDateOfWeek(dayInWeek, defaultCultureInfo);
      }
      public static DateTime GetFirstDateOfWeek(DateTime dayInWeek, CultureInfo cultureInfo)
      {
         DayOfWeek firstDay = cultureInfo.DateTimeFormat.FirstDayOfWeek;
         DateTime firstDayInWeek = dayInWeek.Date;
         while (firstDayInWeek.DayOfWeek != firstDay)
            firstDayInWeek = firstDayInWeek.AddDays(-1);

         return firstDayInWeek;
      }

   }
}
