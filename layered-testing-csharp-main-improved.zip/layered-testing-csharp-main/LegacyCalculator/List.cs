﻿using System;

namespace Gas
{
   internal class List<T1, T2>
   {
      public List()
      {
      }

      internal void Add(int v)
      {
         throw new NotImplementedException();
      }

      internal void Add(int v, DateTime dateTime)
      {
         throw new NotImplementedException();
      }
   }
}